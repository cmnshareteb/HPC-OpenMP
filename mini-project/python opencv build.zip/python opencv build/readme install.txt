C:\Python27\Lib\site-packages

put pyd it there

C:\Python27\Scripts run pip install numpy